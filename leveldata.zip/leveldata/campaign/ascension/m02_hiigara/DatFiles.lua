-- =============================================================================
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
-- =============================================================================

Dictionaries = {{name = "locale:leveldata/campaign/ascension/m02_hiigara.dat"}, {name = "locale:leveldata/campaign/ascension/NIS02A_M02_Hiigara.dat"}, {name = "locale:leveldata/campaign/ascension/NIS02B_M02_Hiigara.dat"},}
