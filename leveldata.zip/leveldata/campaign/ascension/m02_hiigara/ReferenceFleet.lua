-- =============================================================================
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
-- =============================================================================

Fleet = {
	{Type = "Sp_Tanker", Number = 6},
	{Type = "Hgn_Mothership", Number = 1},
	{Type = "Hgn_ResourceCollector", Number = 1},
	{Type = "Hgn_Interceptor", Number = 3},
	{Type = "Hgn_AttackBomber", Number = 2},}

RUs = 1300
