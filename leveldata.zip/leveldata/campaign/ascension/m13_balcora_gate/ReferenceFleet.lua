-- =============================================================================
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
-- =============================================================================

Fleet = {
	{Type = "Hgn_MotherShip", Number = 1},
	{Type = "Hgn_Shipyard", Number = 1},
	{Type = "Hgn_Dreadnaught", Number = 1},
	{Type = "Hgn_ResourceCollector", Number = 7},
	{Type = "Hgn_ResourceController", Number = 1},
	{Type = "Hgn_Interceptor", Number = 1},
	{Type = "Hgn_AttackBomber", Number = 4},
	{Type = "Hgn_MarineFrigate", Number = 1},
	{Type = "Hgn_AssaultFrigate", Number = 5},
	{Type = "Hgn_TorpedoFrigate", Number = 3},
	{Type = "Hgn_Carrier", Number = 1},
	{Type = "Hgn_DefenseFieldFrigate", Number = 1},
	{Type = "Hgn_IonCannonFrigate", Number = 1},
	{Type = "Hgn_Destroyer", Number = 1},
	{Type = "Kpr_Mover", Number = 5},
	{Type = "Hgn_BattleCruiser", Number = 1},}

RUs = 7500
