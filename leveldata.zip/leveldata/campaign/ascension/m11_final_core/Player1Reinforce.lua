-- =============================================================================
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
-- =============================================================================

Reinforcements = {
	{Type = "Vgr_Interceptor", Weight = 1}, 
	{Type = "Vgr_Bomber", Weight = 1}, 
	{Type = "Vgr_HeavyMissileFrigate", Weight = 1}, 
	{Type = "Vgr_AssaultFrigate", Weight = 1}, 
	{Type = "Vgr_MissileCorvette", Weight = 1}, 
	{Type = "Vgr_LaserCorvette", Weight = 1},}
