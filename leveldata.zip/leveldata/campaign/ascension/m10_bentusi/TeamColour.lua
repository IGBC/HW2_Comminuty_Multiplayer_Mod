-- =============================================================================
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
-- =============================================================================

teamcolours = {
	[0] = {{0.365, 0.553, 0.667}, {0.8, 0.8, 0.8}, "DATA:Badges/Hiigaran.tga"}, 
	[1] = {{0, 0.925, 0.521}, {0.1, 0.1, 0.1}, "DATA:Badges/Vaygr.tga"}, 
	[2] = {{0.752, 0.694, 0.556}, {1, 1, 1}, "DATA:Badges/Hiigaran.tga"},}
