shipManifest={
	{
		name="Hgn_Destroyer",
		M3={"T",4,{"hgn_DDK"}}
	}
};